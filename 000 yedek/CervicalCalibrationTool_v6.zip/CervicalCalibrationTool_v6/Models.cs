using System;
using System.Collections.Generic;

namespace CervicalCalibrationTool;

public sealed class SampleRecord
{
    public long SampleIndex { get; init; }
    public double TimeSeconds { get; init; }
    public ushort Adc { get; init; }
    public double RawVoltage { get; init; }
    public double NotchVoltage { get; init; }
    public double FilteredVoltage { get; init; }
    public bool Artifact { get; init; }
}

public sealed class CalibrationPoint
{
    public string Sensor { get; init; } = string.Empty;
    public int Channel { get; init; }
    public string Unit { get; init; } = string.Empty;
    public double KnownValue { get; init; }
    public double MeanRawVoltage { get; init; }
    public double MeanFilteredVoltage { get; init; }
    public double StandardDeviationVolts { get; init; }
    public double PeakToPeakVolts { get; init; }
    public double DriftVoltsPerSecond { get; init; }
    public double ArtifactFraction { get; init; }

    public double StandardDeviationMillivolts => StandardDeviationVolts * 1000.0;
    public double PeakToPeakMillivolts => PeakToPeakVolts * 1000.0;
    public double DriftMillivoltsPerSecond => DriftVoltsPerSecond * 1000.0;
    public double ArtifactPercent => ArtifactFraction * 100.0;
    public int SampleCount { get; init; }
    public DateTime CapturedAt { get; init; } = DateTime.Now;
}

public sealed class LinearCalibrationResult
{
    public string Sensor { get; init; } = string.Empty;
    public int PointCount { get; init; }
    public double Slope { get; init; }
    public double Offset { get; init; }
    public double RSquared { get; init; }
    public double Rmse { get; init; }

    public double Convert(double voltage) => (Slope * voltage) + Offset;
}

public sealed class SingleChannelCalibrationFile
{
    public string FileFormat { get; set; } = "CervicalCalibrationTool.SingleChannel.v2";
    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public string Sensor { get; set; } = string.Empty;
    public int Channel { get; set; }
    public string Unit { get; set; } = string.Empty;
    public double OutputMultiplier { get; set; } = 1.0;
    public SensorConfig Calibration { get; set; } = new();
    public CalibrationQuality Quality { get; set; } = new();
    public AcquisitionInfo Acquisition { get; set; } = new();
    public FilterSettings Filters { get; set; } = new();
    public List<CalibrationPoint> Points { get; set; } = new();
}

public sealed class SensorConfig
{
    public double Slope { get; set; } = 1.0;
    public double Offset { get; set; }
    public double Zero { get; set; }
}

public sealed class CalibrationQuality
{
    public double RSquared { get; set; }
    public double Rmse { get; set; }
    public int PointCount { get; set; }
}

public sealed class AcquisitionInfo
{
    public int BoardNumber { get; set; }
    public string InputRange { get; set; } = string.Empty;
    public int RequestedSamplingRate { get; set; }
    public int ActualSamplingRate { get; set; }
    public double StableWindowSeconds { get; set; }
    public double AutomaticWarmupSeconds { get; set; }
    public double MinimumAcquisitionSeconds { get; set; }
}
