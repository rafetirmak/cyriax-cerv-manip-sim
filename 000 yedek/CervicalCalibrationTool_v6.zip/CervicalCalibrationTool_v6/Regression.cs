using System;
using System.Collections.Generic;
using System.Linq;

namespace CervicalCalibrationTool;

public static class Regression
{
    public static LinearCalibrationResult Fit(
        string sensor,
        IEnumerable<CalibrationPoint> source)
    {
        CalibrationPoint[] points = source
            .Where(point => string.Equals(point.Sensor, sensor, StringComparison.OrdinalIgnoreCase))
            .ToArray();

        if (points.Length < 2)
            throw new InvalidOperationException($"{sensor} requires at least two calibration points.");

        double meanX = points.Average(point => point.MeanFilteredVoltage);
        double meanY = points.Average(point => point.KnownValue);

        double sxx = points.Sum(point => Math.Pow(point.MeanFilteredVoltage - meanX, 2));
        if (sxx <= 1e-18)
            throw new InvalidOperationException($"{sensor} calibration point voltages must be different.");

        double sxy = points.Sum(point =>
            (point.MeanFilteredVoltage - meanX) * (point.KnownValue - meanY));

        double slope = sxy / sxx;
        double offset = meanY - (slope * meanX);

        double sse = points.Sum(point =>
        {
            double prediction = (slope * point.MeanFilteredVoltage) + offset;
            return Math.Pow(point.KnownValue - prediction, 2);
        });

        double sst = points.Sum(point => Math.Pow(point.KnownValue - meanY, 2));
        double rSquared = sst <= 1e-18 ? 1.0 : 1.0 - (sse / sst);
        double rmse = Math.Sqrt(sse / points.Length);

        return new LinearCalibrationResult
        {
            Sensor = sensor,
            PointCount = points.Length,
            Slope = slope,
            Offset = offset,
            RSquared = rSquared,
            Rmse = rmse
        };
    }
}
