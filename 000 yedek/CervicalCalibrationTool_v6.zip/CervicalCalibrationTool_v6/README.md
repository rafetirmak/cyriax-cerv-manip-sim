# CervicalCalibrationTool v6 — Automatic Single-Measurement Cycles

This version calibrates **one DAQ channel per session** and treats every START/STOP cycle as one independent calibration measurement.

## Measurement workflow

1. Select `Force — Channel 0` or `Angle — Channel 1`.
2. Enter the measured reference value.
3. Apply the load and allow the mechanical setup to settle.
4. Press **START**.
5. The program calculates the minimum acquisition time automatically.
6. The STOP button remains disabled until enough samples have been collected.
7. When the button changes to **STOP & SAVE POINT**, press it once.
8. The final stable window is checked and, if accepted, one calibration point is added automatically.
9. The temporary raw sample list, graph data, filter state and MCC memory buffer are then cleared.

Only accepted calibration-point summaries remain in the table. A new START begins with a completely fresh acquisition buffer.

## Automatic minimum acquisition time

The minimum duration is calculated as:

`automatic filter settling time + selected stable-window duration`

The settling period is the largest of:

- a conservative 1.0 s minimum,
- the estimated 50 Hz notch settling time,
- the Hampel-window fill time,
- the estimated fourth-order low-pass settling time.

With the default settings (1000 Hz, 50 Hz notch Q=30, Hampel window 101, low-pass 10 Hz, stable window 5 s), the automatic minimum is approximately **6.00 seconds** and the accepted point contains the final **5000 samples**.

## STOP behavior

- Before the automatic minimum is reached: STOP is disabled and displays `COLLECTING...`.
- After the minimum is reached: it displays `STOP & SAVE POINT`.
- On STOP: the final stable window is checked against SD, drift and artifact limits.
- If accepted: exactly one point is added.
- If rejected: no point is added and the temporary buffer is still cleared so the measurement can be repeated cleanly.

## Raw voltage files

The full temporary raw trace can still be exported with **SAVE CURRENT RAW (.CSV)** after the automatic minimum has been reached and before STOP is pressed. STOP intentionally clears the temporary raw trace. Every accepted point always retains its mean raw voltage, mean filtered voltage, SD, peak-to-peak value, drift, artifact percentage and sample count.

## Stability check

The calibration value is calculated from the final low-pass-filtered voltage. Stability is evaluated on the 50 Hz notch-filtered signal rather than the more strongly smoothed low-pass output, so slow motion is less likely to be hidden.

## Signal chain

`raw voltage -> 50 Hz notch -> Hampel spike suppression -> 4th-order low-pass`

No high-pass filter is used, so the static/DC calibration level is preserved.

## DAQ configuration

- Measurement Computing Universal Library
- Board number: 0
- Selectable channel: Ch0 or Ch1
- Input range: Bip10Volts
- Requested rate: 1000 samples/s
- Continuous circular buffer aligned to the USB-1608FS 31-sample packet size
- Platform: x64, .NET 8 Windows Forms

The buffer reader includes the most recently completed sample reported by `GetStatus`. The MCC memory buffer is allocated at START and freed at STOP.

## Output format

Each exported channel-specific JSON file includes:

- sensor name, channel and unit,
- slope, offset and zero,
- R-squared, RMSE and point count,
- requested and actual sampling rates,
- stable-window duration,
- automatic warm-up duration,
- total minimum acquisition duration,
- filter settings,
- all accepted calibration points.

The file format identifier is `CervicalCalibrationTool.SingleChannel.v2`.
