# Validation notes — v6 automatic measurement cycles

## Structural checks performed

- Form1.cs was checked for balanced braces, parentheses, brackets and string delimiters.
- The old manual `CAPTURE STABLE POINT` event path was removed.
- START clears the temporary software sample lists and allocates a fresh MCC buffer.
- STOP is enabled only after `_minimumMeasurementSamples` has been reached.
- User STOP performs one automatic stable-window capture and then clears the temporary sample lists, graph, filter pipeline and MCC memory buffer.
- Accepted `CalibrationPoint` objects remain in the table after the transient sample buffer is cleared.
- The newest completed single-channel sample is included by treating `currentIndex + 1` as the exclusive buffer endpoint.
- JSON format was updated to `CervicalCalibrationTool.SingleChannel.v2` and includes automatic timing metadata.

## Default timing calculation

At 1000 samples/s with the default settings:

- stable window: 5.00 s = 5000 samples,
- notch estimate: approximately 0.955 s,
- Hampel fill time: 0.101 s,
- low-pass estimate: approximately 0.318 s,
- conservative warm-up selected: 1.00 s = 1000 samples,
- automatic minimum: 6.00 s = 6000 samples.

The accepted point contains the final 5000 samples; the first 1000 samples are settling/warm-up data and are not included in the point calculation.

## Hardware validation still required

This environment does not contain the USB-1608FS device or the .NET 8 SDK. Verify on the acquisition PC:

1. STOP displays `COLLECTING...` and remains disabled for approximately 6 s with default settings.
2. STOP changes to `STOP & SAVE POINT` only after at least 6000 samples are available.
3. One accepted point is added when STOP is pressed.
4. The graph and live voltage fields clear immediately after STOP.
5. A new START begins at sample index 0 and contains no samples from the previous measurement.
6. An unstable final window is rejected, leaves no point, and still clears the temporary buffer.
7. `SAVE CURRENT RAW (.CSV)` works before STOP and the CSV contains only the current START/STOP measurement.
8. The exported JSON contains stable-window, automatic-warm-up and minimum-acquisition durations.
